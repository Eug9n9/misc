jQuery(document).ready(function($) {
/*
    $(".all-cat-nav .icon").click(function() {
        $(".all-cat-nav").toggleClass("open");
        $(".social-nav").removeClass("open");
        $(".about-nav").removeClass("open");
        $(".search-nav").removeClass("open");
    });

    $(".all-cat .cat-item").hover(function() {
        $(this).toggleClass("open");
    });

    $(".main-cat-nav .cat").hover(function() {
        //	$( this ).toggleClass( "open" );
        $(".social-nav").removeClass("open");
        $(".about-nav").removeClass("open");
        $(".all-cat-nav").removeClass("open");
        $(".search-nav").removeClass("open");
    });
/*
    $(".about-nav .btn").click(function() {
        $(".about-nav").toggleClass("open");
        $(".social-nav").removeClass("open");
        $(".all-cat-nav").removeClass("open");
    });

    $(".social-nav .btn").click(function() {
        $(".social-nav").toggleClass("open");
        $(".about-nav").removeClass("open");
        $(".all-cat-nav").removeClass("open");
    });

    $(".search-nav .icon").click(function() {
        $(".search-nav").addClass("open");
        $(".search-nav .text").focus();
        $(".social-nav").removeClass("open");
        $(".about-nav").removeClass("open");
        $(".all-cat-nav").removeClass("open");
    });

    $(".search-nav .close-btn").click(function() {
        $(".search-nav").removeClass("open");
        $(".search-nav .text").focusout();
    });
*/

//$('.gallery-01').carousel({ autoRotate: 4000 });
//$('.gallery-02').carousel({ visible: 4, itemMargin: 0, itemMinWidth: 285 });
/*
    $('.entry-content').stickem({
        offset: 52,
        start: 280
    });

    $('li.cat-item:has(ul.children)').addClass('dropdown');

    $('.main-cat-nav .cat').hoverIntent({
        over: function() {
            $(".main-cat-dropdown .container .row").addClass("loading").show();
            var classes = $(this).attr('class').split('cat-item-');
            var categId = classes[1];
            $.ajax({
                url: "/wp-admin/admin-ajax.php",
                type: 'POST',
                data: 'action=dropdown_last_posts&catid=' + categId,
                success: function(results) {
                    $(".main-cat-dropdown .container .row").removeClass("loading").html(results);
                }
            });
        },
        out: function() {
            $(".main-cat-dropdown .container .row").hide().html("");
        },
        interval: 100
    });

    $('ul.sub-cat .cat-item').hoverIntent({
        over: function() {
            $(".main-cat-dropdown .container .row").addClass("loading").show().html("");
            var classes = $(this).attr('class').split('cat-item-');
            var classes = classes[classes.length - 1].split(' ');
            var categId = classes[0];
            $.ajax({
                url: "/wp-admin/admin-ajax.php",
                type: 'POST',
                data: 'action=dropdown_last_posts&catid=' + categId,
                success: function(results) {
                    $(".main-cat-dropdown .container .row").removeClass("loading").html(results);

                }
            });
        },
        out: function() {
            //$( ".main-cat-dropdown .container .row" ).hide();
        },
        interval: 300
    });
*/
    $('#carousel-featured').carousel();

    $("#carousel-featured .carousel-inner").swipe({
        swipeLeft: function(event, direction, distance, duration, fingerCount) {
            $(this).parent().carousel('next');
        },
        swipeRight: function() {
            $(this).parent().carousel('prev');
        },
        threshold: 0
    });

//    Shadowbox.init();
});

